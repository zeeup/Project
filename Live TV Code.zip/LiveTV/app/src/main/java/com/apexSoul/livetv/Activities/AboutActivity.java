package com.apexSoul.livetv.Activities;

import android.content.Context;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.apexSoul.livetv.R;

public class AboutActivity extends AppCompatActivity {

    Toolbar toolbar;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        initUI();
        clickListeners();
    }


    private void initUI() {
        context = AboutActivity.this;
        toolbar = findViewById(R.id.toolbar);
    }


    private void clickListeners() {

        toolbar.setNavigationOnClickListener(view -> onBackPressed());

    }
}