package com.apexSoul.livetv.Activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Utils.Constants;
import com.apexSoul.livetv.Utils.Functions;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.potyvideo.library.AndExoPlayerView;
import com.potyvideo.library.globalInterfaces.AndExoPlayerListener;

import java.util.HashMap;

@SuppressWarnings("deprecation")
public class ChannelPlayerActivity extends AppCompatActivity {

    Context context;
    String name, link;
    AndExoPlayerView andExoPlayerView;
    YouTubePlayerView youTubePlayerView;
    boolean isYoutubePlayer, isExoPlayer;
    RelativeLayout rlRoot;
    SimpleExoPlayer player;
    PlayerView playerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channel_player);
        initUI();
        getIntentValues();
        clickListeners();


    }


    private void initUI() {
        context = ChannelPlayerActivity.this;
        andExoPlayerView = findViewById(R.id.andExoPlayerView);
        youTubePlayerView = findViewById(R.id.youtube_player_view);
        rlRoot = findViewById(R.id.root);
        playerView = findViewById(R.id.player_view);


        player = ExoPlayerFactory.newSimpleInstance(getApplicationContext());


        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());


    }

    private void getIntentValues() {
        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        link = intent.getStringExtra("link");

        identifyLinks();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showFullScreenAds();

            }
        },1000);
    }

    private void showFullScreenAds() {
        if (Constants.FACEBOOK_ADS) {
            final InterstitialAd fbInterstitialAd = new com.facebook.ads.InterstitialAd(this, Constants.FACEBOOK_INTER);
            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    /// Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    //Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    fbInterstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    //  Log.d(TAG, "Interstitial ad impression logged!");
                }
            };
            fbInterstitialAd.loadAd(
                    fbInterstitialAd.buildLoadAdConfig()
                            .withAdListener(interstitialAdListener)
                            .build());
        } else {


            final com.google.android.gms.ads.InterstitialAd interstitialAd = new com.google.android.gms.ads.InterstitialAd(this);
            interstitialAd.setAdUnitId(Constants.ADMOB_INTER);
            AdRequest request = new AdRequest.Builder().build();
            interstitialAd.loadAd(request);
            interstitialAd.setAdListener(new AdListener() {
                public void onAdLoaded() {
                    if (interstitialAd.isLoaded()) {
                        interstitialAd.show();
                    }
                }
            });

        }
    }


    private void identifyLinks() {

        if (Functions.isYoutubeUrl(link)) {

            isYoutubePlayer = true;
            youTubePlayerView.setVisibility(View.VISIBLE);
            andExoPlayerView.setVisibility(View.GONE);
            playerView.setVisibility(View.GONE);
            setYoutubePlayer(link);

        } else if (link.contains("https://manifest.googlevideo.com")) {

            isYoutubePlayer = false;
            isExoPlayer = true;

            andExoPlayerView.setVisibility(View.VISIBLE);
            playerView.setVisibility(View.VISIBLE);

            Functions.hideSystemUI(context);

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);


            setExoPlayer(link);

        } else {

            isYoutubePlayer = false;
            andExoPlayerView.setVisibility(View.VISIBLE);
            youTubePlayerView.setVisibility(View.GONE);
            playerView.setVisibility(View.GONE);
            setM3u8Player(link);

        }


    }

    private void setExoPlayer(String link) {


        playerView.setPlayer(player);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);

        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(getApplicationContext(), Util.getUserAgent(getApplicationContext(), getApplicationContext().getString(R.string.app_name)));

        MediaSource videoSource = new HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(Uri.parse(link));

        player.prepare(videoSource);
        player.setPlayWhenReady(true);

    }

    private void setM3u8Player(String link) {


        HashMap<String, String> extraHeaders = new HashMap<>();
        extraHeaders.put("foo", "bar");
        andExoPlayerView.setSource(link, extraHeaders);

        AppCompatImageButton appCompatImageButton = andExoPlayerView.getEnterFullScreen();

        appCompatImageButton.performClick();

        andExoPlayerView.setAndExoPlayerListener(new AndExoPlayerListener() {
            @Override
            public void onExoPlayerStart() {

            }

            @Override
            public void onExoPlayerFinished() {

            }

            @Override
            public void onExoPlayerLoading() {

            }

            @Override
            public void onExoPlayerError(String s) {

                andExoPlayerView.setSource(link, extraHeaders);

            }

            @Override
            public void onExoBuffering() {

            }

            @Override
            public void onExoEnded() {

            }

            @Override
            public void onExoIdle() {

            }

            @Override
            public void onExoReady() {

                //  andExoPlayerView.startPlayer();

            }
        });

    }

    private void setYoutubePlayer(String link) {


        youTubePlayerView.setEnableAutomaticInitialization(true);


        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {

                String videoId = Functions.getYoutubeVideoId(link);
                youTubePlayer.loadVideo(videoId, 0);

            }
        });

        youTubePlayerView.enterFullScreen();
        Functions.hideSystemUI(context);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

    }

    @SuppressLint("ClickableViewAccessibility")
    private void clickListeners() {

        youTubePlayerView.addFullScreenListener(new YouTubePlayerFullScreenListener() {
            @Override
            public void onYouTubePlayerEnterFullScreen() {


                Functions.hideSystemUI(context);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);


            }

            @Override
            public void onYouTubePlayerExitFullScreen() {


                // Functions.showSystemUI(context);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                // Functions.setLightStatusBar(context);
            }
        });


    }

    public void onResume() {
        super.onResume();

        Functions.hideSystemUI(context);
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (!isYoutubePlayer) {

            andExoPlayerView.pausePlayer();

        } else {

            youTubePlayerView.release();


        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    // Catch touch events here
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }
}