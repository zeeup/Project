package com.apexSoul.livetv.Activities;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.apexSoul.livetv.Adapters.ChannelAdapter;
import com.apexSoul.livetv.Models.Categories;
import com.apexSoul.livetv.Models.Channels;
import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Utils.Constants;
import com.apexSoul.livetv.Utils.FireRef;
import com.apexSoul.livetv.Utils.LoadingDialog;
import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ChannelsActivity extends AppCompatActivity {
    Context context;
    Toolbar toolbar;
    RecyclerView rvChannels;
    List<Channels> channelsArrayList = new ArrayList<>();
    ChannelAdapter channelAdapter;
    SwipeRefreshLayout swipeRefreshLayout;
    LottieAnimationView lottieAnimationView;
    Categories categoriesIntent;
    TextView tvCategoryName;
    ImageView ivCategory;
    CardView cvBack;
    LoadingDialog loadingDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channels);
        initUI();
        clickListeners();
        showFullScreenAds();

    }


    private void initUI() {
        context = ChannelsActivity.this;
        toolbar = findViewById(R.id.toolbar);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        rvChannels = findViewById(R.id.recyclerView);
        lottieAnimationView = findViewById(R.id.animationView);
        tvCategoryName = findViewById(R.id.tv_category_name);
        ivCategory = findViewById(R.id.iv_category);
        cvBack = findViewById(R.id.cv_back);
    }


    private void getIntentValues() {

        categoriesIntent = (Categories) getIntent().getSerializableExtra(Constants.KEY_REF_CATEGORIES);

        Glide.with(context).load(categoriesIntent.getImg()).into(ivCategory);
        tvCategoryName.setText(categoriesIntent.getName());

        getChannels();
    }

    private void clickListeners() {

        cvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });
    }

    private void getChannels() {

        loadingDialog = new LoadingDialog(context, "Loading");
        loadingDialog.show();

        swipeRefreshLayout.setRefreshing(true);

        Query query = FireRef.CHANNELS.orderByChild(Constants.CATEGORY_ID).equalTo(categoriesIntent.getCategoryId());

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                channelsArrayList.clear();
                swipeRefreshLayout.setRefreshing(false);

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    Channels channels = dataSnapshot.getValue(Channels.class);
                    channelsArrayList.add(channels);

                }

                if (channelsArrayList.size() == 0) {

                    lottieAnimationView.setVisibility(View.VISIBLE);

                } else {

                    lottieAnimationView.setVisibility(View.GONE);

                    channelAdapter = new ChannelAdapter(context, channelsArrayList);
                    rvChannels.setAdapter(channelAdapter);
                }

                loadingDialog.dismiss();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                swipeRefreshLayout.setRefreshing(false);
                loadingDialog.dismiss();
                Toast.makeText(context, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getIntentValues();
        loadAds();
    }

    private void loadAds() {
        if (Constants.FACEBOOK_ADS) {
            com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, Constants.FACEBOOK_BANNER, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            LinearLayout adContainer = findViewById(R.id.adView);
            adContainer.addView(adView);
            adView.loadAd();

        } else {

            AdView adView = new AdView(this);
            adView.setAdUnitId(Constants.ADMOB_BANNER);
            adView.setAdSize(AdSize.BANNER);
            LinearLayout layout = findViewById(R.id.adView);
            layout.addView(adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);

        }
    }

    private void showFullScreenAds() {
        if (Constants.FACEBOOK_ADS) {
            final InterstitialAd fbInterstitialAd = new com.facebook.ads.InterstitialAd(this, Constants.FACEBOOK_INTER);
            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    /// Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    //Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    fbInterstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    //  Log.d(TAG, "Interstitial ad impression logged!");
                }
            };
            fbInterstitialAd.loadAd(
                    fbInterstitialAd.buildLoadAdConfig()
                            .withAdListener(interstitialAdListener)
                            .build());
        }else {

            final com.google.android.gms.ads.InterstitialAd interstitialAd = new com.google.android.gms.ads.InterstitialAd(this);
            interstitialAd.setAdUnitId(Constants.ADMOB_INTER);
            AdRequest request = new AdRequest.Builder().build();
            interstitialAd.loadAd(request);
            interstitialAd.setAdListener(new AdListener() {
                public void onAdLoaded() {
                    if (interstitialAd.isLoaded()) {
                        interstitialAd.show();
                    }
                }
            });

        }
    }

}