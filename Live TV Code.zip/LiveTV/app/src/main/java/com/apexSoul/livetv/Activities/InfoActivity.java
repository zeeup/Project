package com.apexSoul.livetv.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Utils.Constants;
import com.apexSoul.livetv.Utils.Functions;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class InfoActivity extends AppCompatActivity {

    Context context;
    LinearLayout llRateUs, llContactUs, llShare, llAbout, llPrivacy;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        initUI();
        clickListeners();
        showFullScreenAds();
    }

    private void initUI() {
        context = InfoActivity.this;
        toolbar = findViewById(R.id.toolbar);
        llRateUs = findViewById(R.id.ll_rate_us);
        llContactUs = findViewById(R.id.ll_contact_us);
        llShare = findViewById(R.id.ll_share);
        llAbout = findViewById(R.id.ll_about);
        llPrivacy = findViewById(R.id.ll_privacy);
    }

    private void clickListeners() {

        llRateUs.setOnClickListener(view -> Functions.openPlayStore(context));

        llContactUs.setOnClickListener(view -> Functions.sendEmail(context, "Send Feedback", " zfiaz45@gmail.com"));

        llShare.setOnClickListener(view -> Functions.shareApp(context));

        llAbout.setOnClickListener(view -> startActivity(new Intent(context, AboutActivity.class)));

        llPrivacy.setOnClickListener(view -> Functions.openBrowser(context, "http://www.google.com"));

        toolbar.setNavigationOnClickListener(view -> onBackPressed());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAds();
    }

    private void loadAds() {
        if (Constants.FACEBOOK_ADS) {
            com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, Constants.FACEBOOK_BANNER, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            LinearLayout adContainer = findViewById(R.id.adView);
            adContainer.addView(adView);
            adView.loadAd();

        } else {

            AdView adView = new AdView(this);
            adView.setAdUnitId(Constants.ADMOB_BANNER);
            adView.setAdSize(AdSize.BANNER);
            LinearLayout layout = findViewById(R.id.adView);
            layout.addView(adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);

        }
    }

    private void showFullScreenAds() {
        if (Constants.FACEBOOK_ADS) {
            final InterstitialAd fbInterstitialAd = new com.facebook.ads.InterstitialAd(this, Constants.FACEBOOK_INTER);
            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    /// Log.e(TAG, "Interstitial ad displayed.");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    // Log.e(TAG, "Interstitial ad dismissed.");
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    //Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                    fbInterstitialAd.show();
                }

                @Override
                public void onAdClicked(Ad ad) {
                    // Log.d(TAG, "Interstitial ad clicked!");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    //  Log.d(TAG, "Interstitial ad impression logged!");
                }
            };
            fbInterstitialAd.loadAd(
                    fbInterstitialAd.buildLoadAdConfig()
                            .withAdListener(interstitialAdListener)
                            .build());
        } else {

            final com.google.android.gms.ads.InterstitialAd interstitialAd = new com.google.android.gms.ads.InterstitialAd(this);
            interstitialAd.setAdUnitId(Constants.ADMOB_INTER);
            AdRequest request = new AdRequest.Builder().build();
            interstitialAd.loadAd(request);
            interstitialAd.setAdListener(new AdListener() {
                public void onAdLoaded() {
                    if (interstitialAd.isLoaded()) {
                        interstitialAd.show();
                    }
                }
            });

        }
    }

}