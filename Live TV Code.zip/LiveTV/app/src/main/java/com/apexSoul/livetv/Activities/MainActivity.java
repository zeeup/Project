package com.apexSoul.livetv.Activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.apexSoul.livetv.Adapters.CategoriesAdapter;
import com.apexSoul.livetv.Models.Categories;
import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Services.NetworkStateListener;
import com.apexSoul.livetv.Utils.Constants;
import com.apexSoul.livetv.Utils.FireRef;
import com.apexSoul.livetv.Utils.Functions;
import com.apexSoul.livetv.Utils.LoadingDialog;
import com.apexSoul.livetv.Utils.NetworkDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Context context;
    Toolbar toolbar;
    RecyclerView rvCategories;
    ArrayList<Categories> categoriesArrayList = new ArrayList<>();
    CategoriesAdapter categoriesAdapter;
    SwipeRefreshLayout swipeRefreshLayout;
    ImageView ivMore, ivInfo;
    LottieAnimationView lottieAnimationView;
    LoadingDialog loadingDialog;
    NetworkStateListener networkStateListener;
    NetworkDialog networkDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUI();
        clickListeners();
        loadAds();

    }


    private void initUI() {
        context = MainActivity.this;
        toolbar = findViewById(R.id.toolbar);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        rvCategories = findViewById(R.id.recyclerView);
        lottieAnimationView = findViewById(R.id.animationView);
        ivMore = findViewById(R.id.iv_more);
        ivInfo = findViewById(R.id.iv_info);

        networkDialog = new NetworkDialog(context);

    }


    private void clickListeners() {

        swipeRefreshLayout.setOnRefreshListener(this::getChannelCategories);

        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        ivMore.setOnClickListener(view -> showMorePopUp());

        ivInfo.setOnClickListener(view -> startActivity(new Intent(context, InfoActivity.class)));

    }

    private void showMorePopUp() {


        PopupMenu popup = new PopupMenu(context, ivMore);
        popup.inflate(R.menu.more_menu);

        popup.setOnMenuItemClickListener(item -> {

            startActivity(new Intent(context, AboutActivity.class));

            return true;
        });
        popup.show();


    }

    private void getChannelCategories() {

        loadingDialog = new LoadingDialog(context, "Loading");
        loadingDialog.show();

        swipeRefreshLayout.setRefreshing(true);


        FireRef.CATEGORIES.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                categoriesArrayList.clear();
                swipeRefreshLayout.setRefreshing(false);


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    Categories channels = dataSnapshot.getValue(Categories.class);
                    categoriesArrayList.add(channels);

                }

                if (categoriesArrayList.size() == 0) {

                    lottieAnimationView.setVisibility(View.VISIBLE);

                } else {

                    lottieAnimationView.setVisibility(View.GONE);

                    categoriesAdapter = new CategoriesAdapter(context, categoriesArrayList);
                    rvCategories.setAdapter(categoriesAdapter);
                }

                loadingDialog.dismiss();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                loadingDialog.dismiss();
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(context, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onResume() {
        super.onResume();
        getChannelCategories();

        networkStateListener = new NetworkStateListener();
        registerReceiver(networkStateListener, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

    }

    private void loadAds() {

        if (Constants.FACEBOOK_ADS) {
            com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, Constants.FACEBOOK_BANNER, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            LinearLayout adContainer = findViewById(R.id.adView);
            adContainer.addView(adView);
            adView.loadAd();

        } else {

            AdView adView = new AdView(this);
            adView.setAdUnitId(Constants.ADMOB_BANNER);
            adView.setAdSize(AdSize.BANNER);
            LinearLayout layout = findViewById(R.id.adView);
            layout.addView(adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);
        }
    }

    @Override
    public void onBackPressed() {
        showExitDialog();
    }

    private void showExitDialog() {

        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.exit_confirm_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT);
        dialog.show();

        Button btnYes = dialog.findViewById(R.id.btn_yes);
        Button btnNo = dialog.findViewById(R.id.btn_no);
        ImageView ivLogo = dialog.findViewById(R.id.iv_logo);


        btnYes.setOnClickListener(view -> {

            dialog.dismiss();
            MainActivity.super.onBackPressed();

        });

        btnNo.setOnClickListener(view -> dialog.dismiss());

        ivLogo.setOnClickListener(view -> Functions.openPlayStore(context));

    }

    public void showNetworkMessage(boolean isConnAvailable) {


        if (isConnAvailable) {

            if (networkDialog.isShowing()) {

                networkDialog.dismiss();

            }

        } else {

            networkDialog.show();

        }

    }

}