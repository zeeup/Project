package com.apexSoul.livetv.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Utils.Functions;

public class SplashActivity extends AppCompatActivity {
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        context = SplashActivity.this;
        Functions.hideSystemUI(context);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                finish();
                startActivity(new Intent(context,MainActivity.class));

            }
        }, 1000);


    }
}