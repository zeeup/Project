package com.apexSoul.livetv.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.apexSoul.livetv.Activities.ChannelsActivity;
import com.apexSoul.livetv.Models.Categories;
import com.apexSoul.livetv.R;
import com.apexSoul.livetv.Utils.Constants;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.ArrayList;


public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.CategoryViewHolder> {

    private Context mCtx;
    private ArrayList<Categories> categoriesArrayList;


    public CategoriesAdapter(Context mCtx, ArrayList<Categories> categoriesArrayList) {
        this.mCtx = mCtx;
        this.categoriesArrayList = categoriesArrayList;
    }

    @Override
    public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Categories categories = categoriesArrayList.get(position);

        holder.pbLoading.setVisibility(View.VISIBLE);
        Glide.with(mCtx)
                .load(categories.getImg())
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.pbLoading.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.pbLoading.setVisibility(View.GONE);
                        return false;
                    }
                })
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.imageView);

        holder.textView.setText(categories.getName());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mCtx, ChannelsActivity.class);
                intent.putExtra(Constants.KEY_REF_CATEGORIES, categoriesArrayList.get(position));
                mCtx.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return categoriesArrayList.size();
    }

    class CategoryViewHolder extends RecyclerView.ViewHolder {


        ImageView imageView;
        TextView textView;
        ProgressBar pbLoading;

        public CategoryViewHolder(View itemView) {
            super(itemView);


            imageView = itemView.findViewById(R.id.channelImage);
            textView = itemView.findViewById(R.id.channelName);
            pbLoading = itemView.findViewById(R.id.pb_loading);

        }

    }

}
