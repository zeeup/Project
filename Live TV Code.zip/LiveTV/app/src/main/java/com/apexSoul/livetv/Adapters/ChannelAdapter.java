package com.apexSoul.livetv.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;


import com.apexSoul.livetv.Activities.ChannelPlayerActivity;
import com.apexSoul.livetv.Models.Channels;
import com.apexSoul.livetv.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.ArrayList;
import java.util.List;


public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.CategoryViewHolder> implements Filterable {

    private final Context mCtx;
    private final List<Channels> wallpaperList;
    private List<Channels> searchList;


    public ChannelAdapter(Context mCtx, List<Channels> wallpaperList) {
        this.mCtx = mCtx;
        this.wallpaperList = wallpaperList;
        this.searchList = wallpaperList;
    }

    @Override
    public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.item_channels, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryViewHolder holder, final int position) {

        Channels channel = searchList.get(position);

        holder.pbLoading.setVisibility(View.VISIBLE);
        Glide.with(mCtx)
                .load(channel.getImg())
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.pbLoading.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.pbLoading.setVisibility(View.GONE);
                        return false;
                    }
                })
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.imageView);

        holder.textView.setText(channel.getChannelName());

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(mCtx, ChannelPlayerActivity.class);
            intent.putExtra("name", channel.getChannelName());
            intent.putExtra("image", channel.getImg());
            intent.putExtra("link", channel.getUrl());
            intent.putExtra("desc", channel.getDes());
            mCtx.startActivity(intent);



        });


    }

    @Override
    public int getItemCount() {
        return searchList.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    searchList = wallpaperList;
                } else {
                    ArrayList<Channels> filteredList = new ArrayList<>();
                    for (Channels row : wallpaperList) {
                        if (row.getChannelName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }
                    searchList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = searchList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                searchList = (ArrayList<Channels>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    class CategoryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        ImageView imageView;
        TextView textView;
        ProgressBar pbLoading;

        public CategoryViewHolder(View itemView) {
            super(itemView);


            imageView = itemView.findViewById(R.id.channelImage);
            textView = itemView.findViewById(R.id.channelName);
            pbLoading = itemView.findViewById(R.id.pb_loading);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {

            int p = getAdapterPosition();
            Channels channel = searchList.get(p);

          /*  Intent intent = new Intent(mCtx, DetailsActivity.class);
            intent.putExtra("name", channel.getChannelName());
            intent.putExtra("image", channel.getChannelImage());
            intent.putExtra("type", channel.getChannelType());
            intent.putExtra("linkSd", channel.getChannelLinkSd());
            intent.putExtra("linkHd", channel.getChannelLinkHd());
            intent.putExtra("desc", channel.getChannelDesc());
            intent.putExtra("category", channel.getChannelCategory());
            intent.putExtra("id", channel.getId());

            mCtx.startActivity(intent);*/
        }
    }

}
