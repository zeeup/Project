package com.apexSoul.livetv.Models;

import java.io.Serializable;

public class Categories implements Serializable {

    private String name, img, categoryId;

    public Categories() {
    }

    public Categories(String name, String img, String categoryId) {
        this.name = name;
        this.img = img;
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    @Override
    public String toString() {
        return name;
    }
}
