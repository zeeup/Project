package com.apexSoul.livetv.Models;

public class Channels {

    private String id, img, channelName, des, Url,categoryId;

    public Channels() {
    }

    public Channels(String id, String img, String channelName, String des, String url, String categoryId) {
        this.id = id;
        this.img = img;
        this.channelName = channelName;
        this.des = des;
        Url = url;
        this.categoryId = categoryId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }
}
