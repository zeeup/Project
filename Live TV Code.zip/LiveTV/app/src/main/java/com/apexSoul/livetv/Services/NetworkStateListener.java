package com.apexSoul.livetv.Services;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.apexSoul.livetv.Activities.MainActivity;

@SuppressLint("UnsafeProtectedBroadcastReceiver")
@RequiresApi(api = Build.VERSION_CODES.O)
public class NetworkStateListener extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isConnAvailable = cm.getActiveNetworkInfo() != null;


            ((MainActivity) context).showNetworkMessage(isConnAvailable);

    }
}
