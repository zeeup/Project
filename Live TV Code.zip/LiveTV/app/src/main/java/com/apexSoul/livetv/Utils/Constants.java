package com.apexSoul.livetv.Utils;


public class Constants {

    public static final long SPLASH_DURATION = 500;
    public static final String KEY_REF_CATEGORIES = "allCategories";
    public static final String KEY_REF_CHANNELS = "allChannels";

    
    //if you want facebook ads , put "true"
    public static final boolean FACEBOOK_ADS = false;

    //Admob AND FACEBOOK Ads ID's

    /*public static final String ADMOB_BANNER = "ca-app-pub-3940256099942544/6300978111";
    public static final String ADMOB_INTER = "ca-app-pub-3940256099942544/1033173712";
*/

      public static final String ADMOB_BANNER = "ca-app-pub-6377544836064700/5837744879";
    public static final String ADMOB_INTER = "ca-app-pub-6377544836064700/5632078354";

    public static final String FACEBOOK_BANNER = "1024433211758773_1024441268424634";
    public static final String FACEBOOK_INTER = "1024433211758773_1024441611757933";


    //----------------------------------------- DO NOT CHANGE ---------------------------------------//


    public static final String DEVICE_ID = "device_id";

    public static final String CATEGORY_ID = "categoryId";

    //------------------------------------------  DO NOT CHANGE  ------------------------------------//

}

