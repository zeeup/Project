package com.apexSoul.livetv.Utils;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FireRef {

    // main initialization
    private static final DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();

    // child initialization
    public static DatabaseReference CHANNELS = myRef.child(Constants.KEY_REF_CHANNELS);
    public static DatabaseReference CATEGORIES= myRef.child(Constants.KEY_REF_CATEGORIES);

}
