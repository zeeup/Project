package com.apexSoul.livetv.Utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.apexSoul.livetv.R;


public class NetworkDialog extends Dialog {

    public NetworkDialog(@NonNull Context context) {
        super(context);
        setContentView(R.layout.network_dialog);
        setCancelable(false);
        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getWindow().setLayout(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT);

        Button btnConnect = findViewById(R.id.btn_connect);


        btnConnect.setOnClickListener(v -> {

            System.exit(0);
            dismiss();


        });
    }
}
