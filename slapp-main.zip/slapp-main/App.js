import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import Route from './src/Route';

export default function App() {
  return (
    <Route />
  );
}
