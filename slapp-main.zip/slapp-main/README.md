
# Slapp

This repository holds code for Slapp. Slapp is a Smart Trading Signals (STS) application which predicts stocks prices using Federated Learning.
The code for Model Training is in repo [SlappModel](https://github.com/RanaMoizHaider/SlappModel) and The code for predicting all the outcomes is in repo [SlappData](https://github.com/RanaMoizHaider/SlappData)
