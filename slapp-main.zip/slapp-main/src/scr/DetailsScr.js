import React from 'react'

function DetailsScr() {
  return (
    <Text>DetailsScr</Text>
  )
}

export default DetailsScr