import React from 'react'
import { Button, Text, View } from 'react-native'

function EditProfileScr() {
  return (
    <Text>EditProfileScr</Text>
  )
}

export default EditProfileScr